# DiamondsPrediction
Udacity's Diamonds Prediction Project in Python
this is a linear regression model that Predicts the prices for a new set of diamonds
